<?php $__env->startSection('title','Argo Create Movie'); ?>

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(url('setting')); ?>" method="post">
    
    <?php echo method_field('put'); ?>    
    <?php echo csrf_field(); ?>

    <div id = "spain">
        <h5>Seleccione una provincia de España:</h5>
            <label for="provinciasEspaña">
                <select name="selectProvincias" id="prov">
                <option value="alava" <?php echo e(session('selectProvincias') === 'alava' ? 'selected' : ''); ?>>Álava</option>
                <option value="albacete" <?php echo e(session('selectProvincias') === 'albacete' ? 'selected' : ''); ?>>Albacete</option>
                <option value="alicante" <?php echo e(session('selectProvincias') === 'alicante' ? 'selected' : ''); ?>>Alicante</option>
                <option value="almeria" <?php echo e(session('selectProvincias') === 'almeria' ? 'selected' : ''); ?>>Almería</option>
                <option value="asturias" <?php echo e(session('selectProvincias') === 'asturias' ? 'selected' : ''); ?>>Asturias</option>
                <option value="avila" <?php echo e(session('selectProvincias') === 'avila' ? 'selected' : ''); ?>>Ávila</option>
                <option value="badajoz" <?php echo e(session('selectProvincias') === 'badajoz' ? 'selected' : ''); ?>>Badajoz</option>
                <option value="barcelona" <?php echo e(session('selectProvincias') === 'barcelona' ? 'selected' : ''); ?>>Barcelona</option>
                <option value="burgos" <?php echo e(session('selectProvincias') === 'burgos' ? 'selected' : ''); ?>>Burgos</option>
                <option value="caceres" <?php echo e(session('selectProvincias') === 'caceres' ? 'selected' : ''); ?>>Cáceres</option>
                <option value="cadiz" <?php echo e(session('selectProvincias') === 'cadiz' ? 'selected' : ''); ?>>Cádiz</option>
                <option value="cantabria" <?php echo e(session('selectProvincias') === 'cantabria' ? 'selected' : ''); ?>>Cantabria</option>
                <option value="castellon" <?php echo e(session('selectProvincias') === 'castellon' ? 'selected' : ''); ?>>Castellón</option>
                <option value="ciudad-real" <?php echo e(session('selectProvincias') === 'ciudad-real' ? 'selected' : ''); ?>>Ciudad Real</option>
                <option value="cordoba" <?php echo e(session('selectProvincias') === 'cordoba' ? 'selected' : ''); ?>>Córdoba</option>
                <option value="cuenca" <?php echo e(session('selectProvincias') === 'cuenca' ? 'selected' : ''); ?>>Cuenca</option>
                <option value="gerona" <?php echo e(session('selectProvincias') === 'gerona' ? 'selected' : ''); ?>>Gerona (Girona)</option>
                <option value="granada" <?php echo e(session('selectProvincias') === 'granada' ? 'selected' : ''); ?>>Granada</option>
                <option value="guadalajara" <?php echo e(session('selectProvincias') === 'guadalajara' ? 'selected' : ''); ?>>Guadalajara</option>
                <option value="guipuzcoa" <?php echo e(session('selectProvincias') === 'guipuzcoa' ? 'selected' : ''); ?>>Guipúzcoa (Gipuzkoa)</option>
                <option value="huelva" <?php echo e(session('selectProvincias') === 'huelva' ? 'selected' : ''); ?>>Huelva</option>
                <option value="huesca" <?php echo e(session('selectProvincias') === 'huesca' ? 'selected' : ''); ?>>Huesca</option>
                <option value="jaen" <?php echo e(session('selectProvincias') === 'jaen' ? 'selected' : ''); ?>>Jaén</option>
                <option value="la-rioja" <?php echo e(session('selectProvincias') === 'la-rioja' ? 'selected' : ''); ?>>La Rioja</option>
                <option value="las-palmas" <?php echo e(session('selectProvincias') === 'las-palmas' ? 'selected' : ''); ?>>Las Palmas</option>
                <option value="leon" <?php echo e(session('selectProvincias') === 'leon' ? 'selected' : ''); ?>>León</option>
                <option value="lleida" <?php echo e(session('selectProvincias') === 'lleida' ? 'selected' : ''); ?>>Lérida (Lleida)</option>
                <option value="lugo" <?php echo e(session('selectProvincias') === 'lugo' ? 'selected' : ''); ?>>Lugo</option>
                <option value="madrid" <?php echo e(session('selectProvincias') === 'madrid' ? 'selected' : ''); ?>>Madrid</option>
                <option value="malaga" <?php echo e(session('selectProvincias') === 'malaga' ? 'selected' : ''); ?>>Málaga</option>
                <option value="murcia" <?php echo e(session('selectProvincias') === 'murcia' ? 'selected' : ''); ?>>Murcia</option>
                <option value="navarra" <?php echo e(session('selectProvincias') === 'navarra' ? 'selected' : ''); ?>>Navarra</option>
                <option value="orense" <?php echo e(session('selectProvincias') === 'orense' ? 'selected' : ''); ?>>Orense (Ourense)</option>
                <option value="palencia" <?php echo e(session('selectProvincias') === 'palencia' ? 'selected' : ''); ?>>Palencia</option>
                <option value="pontevedra" <?php echo e(session('selectProvincias') === 'pontevedra' ? 'selected' : ''); ?>>Pontevedra</option>
                <option value="salamanca" <?php echo e(session('selectProvincias') === 'salamanca' ? 'selected' : ''); ?>>Salamanca</option>
                <option value="santa-cruz-de-tenerife" <?php echo e(session('selectProvincias') === 'santa-cruz-de-tenerife' ? 'selected' : ''); ?>>Santa Cruz de Tenerife</option>
                <option value="segovia" <?php echo e(session('selectProvincias') === 'segovia' ? 'selected' : ''); ?>>Segovia</option>
                <option value="sevilla" <?php echo e(session('selectProvincias') === 'sevilla' ? 'selected' : ''); ?>>Sevilla</option>
                <option value="soria" <?php echo e(session('selectProvincias') === 'soria' ? 'selected' : ''); ?>>Soria</option>
                <option value="tarragona" <?php echo e(session('selectProvincias') === 'tarragona' ? 'selected' : ''); ?>>Tarragona</option>
                <option value="teruel" <?php echo e(session('selectProvincias') === 'teruel' ? 'selected' : ''); ?>>Teruel</option>
                <option value="toledo" <?php echo e(session('selectProvincias') === 'toledo' ? 'selected' : ''); ?>>Toledo</option>
                <option value="valencia" <?php echo e(session('selectProvincias') === 'valencia' ? 'selected' : ''); ?>>Valencia</option>
                <option value="valladolid" <?php echo e(session('selectProvincias') === 'valladolid' ? 'selected' : ''); ?>>Valladolid</option>
                <option value="vizcaya" <?php echo e(session('selectProvincias') === 'vizcaya' ? 'selected' : ''); ?>>Vizcaya (Bizkaia)</option>
                <option value="zamora" <?php echo e(session('selectProvincias') === 'zamora' ? 'selected' : ''); ?>>Zamora</option>
                <option value="zaragoza" <?php echo e(session('selectProvincias') === 'zaragoza' ? 'selected' : ''); ?>>Zaragoza</option>
                </select>
            </label>
    </div>
    
    <div id = "europe">
        <h5>Seleccione un país de Europa:</h5>
            <label for="paisesEuropa">
            <select name="selectPaises" id="paises">
                <option value="albania" <?php echo e(session('selectPaises') === 'albania' ? 'selected' : ''); ?>>Albania</option>
                <option value="alemania" <?php echo e(session('selectPaises') === 'alemania' ? 'selected' : ''); ?>>Alemania</option>
                <option value="andorra" <?php echo e(session('selectPaises') === 'andorra' ? 'selected' : ''); ?>>Andorra</option>
                <option value="austria" <?php echo e(session('selectPaises') === 'austria' ? 'selected' : ''); ?>>Austria</option>
                <option value="belgica" <?php echo e(session('selectPaises') === 'belgica' ? 'selected' : ''); ?>>Bélgica</option>
                <option value="bielorrusia" <?php echo e(session('selectPaises') === 'bielorrusia' ? 'selected' : ''); ?>>Bielorrusia</option>
                <option value="bosnia_herzegovina" <?php echo e(session('selectPaises') === 'bosnia_herzegovina' ? 'selected' : ''); ?>>Bosnia y Herzegovina</option>
                <option value="bulgaria" <?php echo e(session('selectPaises') === 'bulgaria' ? 'selected' : ''); ?>>Bulgaria</option>
                <option value="chipre" <?php echo e(session('selectPaises') === 'chipre' ? 'selected' : ''); ?>>Chipre</option>
                <option value="croacia" <?php echo e(session('selectPaises') === 'croacia' ? 'selected' : ''); ?>>Croacia</option>
                <option value="dinamarca" <?php echo e(session('selectPaises') === 'dinamarca' ? 'selected' : ''); ?>>Dinamarca</option>
                <option value="eslovaquia" <?php echo e(session('selectPaises') === 'eslovaquia' ? 'selected' : ''); ?>>Eslovaquia</option>
                <option value="eslovenia" <?php echo e(session('selectPaises') === 'eslovenia' ? 'selected' : ''); ?>>Eslovenia</option>
                <option value="españa" <?php echo e(session('selectPaises') === 'españa' ? 'selected' : ''); ?>>España</option>
                <option value="estonia" <?php echo e(session('selectPaises') === 'estonia' ? 'selected' : ''); ?>>Estonia</option>
                <option value="finlandia" <?php echo e(session('selectPaises') === 'finlandia' ? 'selected' : ''); ?>>Finlandia</option>
                <option value="francia" <?php echo e(session('selectPaises') === 'francia' ? 'selected' : ''); ?>>Francia</option>
                <option value="grecia" <?php echo e(session('selectPaises') === 'grecia' ? 'selected' : ''); ?>>Grecia</option>
                <option value="hungria" <?php echo e(session('selectPaises') === 'hungria' ? 'selected' : ''); ?>>Hungría</option>
                <option value="irlanda" <?php echo e(session('selectPaises') === 'irlanda' ? 'selected' : ''); ?>>Irlanda</option>
                <option value="islandia" <?php echo e(session('selectPaises') === 'islandia' ? 'selected' : ''); ?>>Islandia</option>
                <option value="italia" <?php echo e(session('selectPaises') === 'italia' ? 'selected' : ''); ?>>Italia</option>
                <option value="letonia" <?php echo e(session('selectPaises') === 'letonia' ? 'selected' : ''); ?>>Letonia</option>
                <option value="liechtenstein" <?php echo e(session('selectPaises') === 'liechtenstein' ? 'selected' : ''); ?>>Liechtenstein</option>
                <option value="lituania" <?php echo e(session('selectPaises') === 'lituania' ? 'selected' : ''); ?>>Lituania</option>
                <option value="luxemburgo" <?php echo e(session('selectPaises') === 'luxemburgo' ? 'selected' : ''); ?>>Luxemburgo</option>
                <option value="malta" <?php echo e(session('selectPaises') === 'malta' ? 'selected' : ''); ?>>Malta</option>
                <option value="moldavia" <?php echo e(session('selectPaises') === 'moldavia' ? 'selected' : ''); ?>>Moldavia</option>
                <option value="monaco" <?php echo e(session('selectPaises') === 'monaco' ? 'selected' : ''); ?>>Mónaco</option>
                <option value="montenegro" <?php echo e(session('selectPaises') === 'montenegro' ? 'selected' : ''); ?>>Montenegro</option>
                <option value="noruega" <?php echo e(session('selectPaises') === 'noruega' ? 'selected' : ''); ?>>Noruega</option>
                <option value="paises_bajos" <?php echo e(session('selectPaises') === 'paises_bajos' ? 'selected' : ''); ?>>Países Bajos</option>
                <option value="polonia" <?php echo e(session('selectPaises') === 'polonia' ? 'selected' : ''); ?>>Polonia</option>
                <option value="portugal" <?php echo e(session('selectPaises') === 'portugal' ? 'selected' : ''); ?>>Portugal</option>
                <option value="reino_unido" <?php echo e(session('selectPaises') === 'reino_unido' ? 'selected' : ''); ?>>Reino Unido</option>
                <option value="republica_checa" <?php echo e(session('selectPaises') === 'republica_checa' ? 'selected' : ''); ?>>República Checa</option>
                <option value="rumania" <?php echo e(session('selectPaises') === 'rumania' ? 'selected' : ''); ?>>Rumanía</option>
                <option value="rusia" <?php echo e(session('selectPaises') === 'rusia' ? 'selected' : ''); ?>>Rusia</option>
                <option value="san_marino" <?php echo e(session('selectPaises') === 'san_marino' ? 'selected' : ''); ?>>San Marino</option>
                <option value="serbia" <?php echo e(session('selectPaises') === 'serbia' ? 'selected' : ''); ?>>Serbia</option>
                <option value="suecia" <?php echo e(session('selectPaises') === 'suecia' ? 'selected' : ''); ?>>Suecia</option>
                <option value="suiza" <?php echo e(session('selectPaises') === 'suiza' ? 'selected' : ''); ?>>Suiza</option>
                <option value="ucrania" <?php echo e(session('selectPaises') === 'ucrania' ? 'selected' : ''); ?>>Ucrania</option>
                <option value="vaticano" <?php echo e(session('selectPaises') === 'vaticano' ? 'selected' : ''); ?>>Ciudad del Vaticano</option>
            </select>
            </label> 
    </div>
    
    <br> <br>
    <button type="submit" class="btn btn-primary">Save setting</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/argoApp/resources/views/setting/index.blade.php ENDPATH**/ ?>